import pickle 
import pandas as pd
import numpy as np
import streamlit as st
import base64

# Background
def add_bg_from_local(image_file):
    with open(image_file, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read())
    st.markdown(
    f"""
    <style>
    .stApp {{
        background-image: url(data:image/{"jfif"};base64,{encoded_string.decode()});
        background-size: cover
    }}
    </style>
    """,
    unsafe_allow_html=True
    )
add_bg_from_local('download.jfif')  
st.title("Product Recomendation system")    
# Product Reccomensation Function from similarities
def recommend(prod,num):
    prod_index=new_df[new_df['name']== prod].index[0]
    distances= similarity[prod_index]
    prod_list=sorted(list(enumerate(distances)),reverse=True,key=lambda x:x[1])[1:num+1]
    l=[]
    for i in prod_list:
        l.append(new_df.iloc[i[0]]['name'])
    return l

#------------------------#
new_df=pickle.load(open("new_df.pkl",'rb')) # Readind the binary file from pickle file
product_list_tuple = tuple(set(new_df['name'].values))
similarity=pickle.load(open("similarity.pkl",'rb'))

# Select input box
selected_name = st.selectbox(
    'Please enter the product name to get reccomendation ',
    product_list_tuple)
st.write('You selected:', selected_name)
number = int(st.number_input('Insert a number',min_value=1,max_value=15,step=1))
st.write('The current number is ', number)
if st.button('Get Recomendations'):
    st.write("---------")
    r=recommend(selected_name,number)
    st.write(r)
